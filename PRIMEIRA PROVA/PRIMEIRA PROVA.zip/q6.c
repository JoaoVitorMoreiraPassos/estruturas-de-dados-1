#include <stdio.h>
#include <string.h>


int vogalOrNo(char c)
{
/*  Recebe um caractere e o compara com as vogais presentes 
    Em um vetor que contém vogais se ele for igual a uma vogal
    Retornará 1, senão retornará 0 */
    char vogais[] = {"AaEeIiOoUu"};
    int i, t = strlen(vogais);
    for (i = 0; i < t; i ++)
    {
        if(c == vogais[i])
        {
            return 1;
        }
    }
    return 0;
}


char * vogais(char *str1, char *str2)
{
/*  Recebe duas strings */
/*  Extrai o tamanho das duas strings*/
    int i, j, t1 = strlen(str1), t2 = strlen(str2), t3 = 0;
/*  Cria um ponteiro de caracteres e o aloca dinamicamente */
    char *str3;
    str3 = (char *) malloc(sizeof(char));
/*  Percorre as duas strings */
    for (i = 0, j = 0; i < t1, j < t2; i ++ , j++)
    {
    /*  Verifica se o caractere i da primeira string é uma vogal
        Se sim, adiciona esse caractere no ponteiro */
        if(vogalOrNo(str1[i]) == 1)
        {
            str3[t3] = str1[i];
            t3 ++;
        }
    /*  Verifica se o caractere j da primeira string é uma vogal
        Se sim, adiciona esse caractere no ponteiro */
        if(vogalOrNo(str2[j]) == 1)
        {
            str3[t3] = str2[j];
            t3 ++;
        }
    /*  Como o caractere da primeira string é sempre analisado primeiro
        Sempre será adiconado primeiro se caso os caracteres atuais das
        Strings forem vogais */
    }
/*  Finaliza o vetor adicionando um '\0' no final */
    str3[t3] = '\0';
/*  Retorna um ponteiro */
    return str3;
}


void main()
{
    char *str1, *str2;
    char *str3;
/*  lê as duas strings */
    scanf(" %[^\n]s", &str1);
    scanf(" %[^\n]s", &str2);
/*  Atribue ao ponteiro o retono a função vogais */    
    str3 = vogais(&str1,&str2);
/*  Mostra caractere por caractere de str3 */
    int i;
    for(i = 0; i < strlen(str3); i ++)
    {
        printf("%c",*(str3+i));
    }
}